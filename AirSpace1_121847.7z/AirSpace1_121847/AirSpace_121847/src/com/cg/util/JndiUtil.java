package com.cg.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.cg.exception.UserException;



public class JndiUtil {

	private DataSource dataSource;
	public JndiUtil() throws UserException {
		try {
			Context ctx = new InitialContext();		//get reference to remote JNDI
			dataSource = (DataSource)ctx.lookup("java:/jdbc/OracleDS");
		} catch (NamingException e) {
			e.printStackTrace();
			throw new UserException("Failed to connect JNDI context",e);
		}
	}
	public Connection getConnection() throws SQLException{
		return dataSource.getConnection();		
	}
}
