package com.cg.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.UserBean.UserBean;
import com.cg.daos.CustomerDao;
import com.cg.daos.CustomerDaoImpl;
import com.cg.exception.UserException;






@WebServlet("*.do")
public class ProcessUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private CustomerDao dao;
	private RequestDispatcher dispatch;
	private String nextJsp;

	public ProcessUser() throws UserException {
		dao= new CustomerDaoImpl();
		
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		process(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		process(request, response);

	}

	public void process(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String path = request.getServletPath();
		System.out.println(path);
		switch (path) {
		case "/enterDetails.do": {
			
			nextJsp="Register.jsp";
			break;

		}
		case "/insert.do": {
			
			String name=request.getParameter("name");
			System.out.println(name);
			String uname=request.getParameter("uname");
			System.out.println(uname);
			String password=request.getParameter("pass");
			System.out.println(password);
			String phone=request.getParameter("phone");
			System.out.println(phone);
			UserBean user = new UserBean();
			user.setName(name);
			user.setuName(uname);
			user.setPassword(password);
			user.setpNo(phone);
			try {
				UserBean u= dao.insertEmp(user);
				System.out.println(u);
				HttpSession session=request.getSession(true);//session created
				session.setAttribute("name1", uname);
				session.setAttribute("phone", phone );
				nextJsp="CustomerHome.jsp";
				
			} catch (UserException e) {
				System.out.println("insert method failed");
			}
			break;
			
		}
		
		case "/calc.do":{
		
			UserBean user=new UserBean();
			LocalDate date=user.getDate();
			String balance=request.getParameter("bal");
			String amount=request.getParameter("pay");
			float balance1=Float.parseFloat(balance);
			float amount1=Float.parseFloat(amount);
			
			float total=balance1-amount1;
			request.setAttribute("paid", amount1);
			request.setAttribute("tot", total);
			
			nextJsp="Success.jsp";
			
			
			break;
			
		}
		case "/paybill.do":{
			HttpSession session=request.getSession(false);//session fetched
			nextJsp="Paybill.jsp";
			
			break;
		}
		
		}

		dispatch = request.getRequestDispatcher(nextJsp);
		dispatch.forward(request, response);
	}
}
