package com.cg.services;

import com.cg.UserBean.UserBean;
import com.cg.daos.CustomerDao;
import com.cg.daos.CustomerDaoImpl;
import com.cg.exception.UserException;

public class CustomerServiceImpl implements CustomerDao {
	
	CustomerDao dao=null;
	
	

	public CustomerServiceImpl() throws UserException {
		dao= new CustomerDaoImpl();
	}



	@Override
	public UserBean insertEmp(UserBean user) throws UserException {
		
		return dao.insertEmp(user);
	}

}
