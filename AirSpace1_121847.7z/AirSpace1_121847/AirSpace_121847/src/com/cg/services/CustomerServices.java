package com.cg.services;

import com.cg.UserBean.UserBean;
import com.cg.exception.UserException;

public interface CustomerServices {
	UserBean insertEmp(UserBean user) throws UserException;

}
