package com.cg.UserBean;

import java.time.LocalDate;

public class UserBean {

	private String name;
	private String uName;
	private String password;
	private String pNo;
	private LocalDate date;
	public UserBean() {
		
	}
	public UserBean(String name, String uName, String password, String pNo,
			LocalDate date) {
		super();
		this.name = name;
		this.uName = uName;
		this.password = password;
		this.pNo = pNo;
		this.date = date;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getuName() {
		return uName;
	}
	public void setuName(String uName) {
		this.uName = uName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getpNo() {
		return pNo;
	}
	public void setpNo(String pNo) {
		this.pNo = pNo;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	@Override
	public String toString() {
		return "UserBean [name=" + name + ", uName=" + uName + ", password="
				+ password + ", pNo=" + pNo + ", date=" + date + "]";
	}
	
	
	
}
