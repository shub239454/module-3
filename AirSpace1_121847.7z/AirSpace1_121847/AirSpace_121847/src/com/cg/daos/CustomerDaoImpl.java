package com.cg.daos;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;


import com.cg.UserBean.UserBean;
import com.cg.exception.UserException;
import com.cg.util.JndiUtil;

public class CustomerDaoImpl implements CustomerDao {
	
	
	JndiUtil util = null;

	public CustomerDaoImpl() throws UserException {
		util = new JndiUtil();
	}

	
	@Override
	public UserBean insertEmp(UserBean user) throws UserException {
		Connection connect = null;
		PreparedStatement pst = null;
		String qry = "INSERT INTO users VALUES(?,?,?,?)";
		try {
			connect = util.getConnection();
			pst = connect.prepareStatement(qry);
			pst.setString(1, user.getName());
			pst.setString(2, user.getuName());
			pst.setString(3, user.getPassword());
			pst.setString(4, user.getpNo());
			int rs = pst.executeUpdate();
			if (rs > 0) {
				System.out.println("record inserted");
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new UserException("insert Failed", e);

		}finally{
			if(pst!=null){
				try {
					pst.close();
				} catch (SQLException e) {
					throw new UserException("pst clossing failed",e);
					
				}
			}
			if(connect!=null){
				try {
					connect.close();
				} catch (SQLException e) {
					throw new UserException("connect clossing failed",e);
				}
			}
		}
	
		return user;
	}
}