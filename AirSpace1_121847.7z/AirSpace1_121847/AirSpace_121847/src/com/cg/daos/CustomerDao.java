package com.cg.daos;

import com.cg.UserBean.UserBean;
import com.cg.exception.UserException;



public interface CustomerDao {
	
	
		UserBean insertEmp(UserBean user) throws UserException;
}
