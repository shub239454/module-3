package com.capgemini.omt.services;

import java.util.List;

import com.capgemini.omt.daos.ShowDao;
import com.capgemini.omt.daos.ShowDaoImpl;
import com.capgemini.omt.dto.Shows;
import com.capgemini.omt.exceptions.ShowException;

public class ShowServiceImpl implements ShowService {
	
	private ShowDao dao;
	public ShowServiceImpl() throws ShowException {
		dao= new ShowDaoImpl();
	}

	@Override
	public List<Shows> showAll() throws ShowException {
		return dao.showAll();
	}

	@Override
	public Shows bookTicket(String name) throws ShowException {
		return dao.bookTicket(name);
	}

	@Override
	public boolean updateSeats(int noOfSeats, String id) throws ShowException {
		return dao.updateSeats(noOfSeats,id);
	}

	
}
