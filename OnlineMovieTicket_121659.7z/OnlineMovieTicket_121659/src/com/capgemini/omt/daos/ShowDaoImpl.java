package com.capgemini.omt.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.omt.dto.Shows;
import com.capgemini.omt.exceptions.ShowException;
import com.capgemini.omt.util.JndiUtil;

public class ShowDaoImpl implements ShowDao {

	private JndiUtil util;

	public ShowDaoImpl() throws ShowException {
		util = new JndiUtil();

	}

	@Override
	public List<Shows> showAll() throws ShowException {
		Connection connect = null;
		PreparedStatement pst = null;
		List<Shows> myShow = new ArrayList<Shows>();
		String query = "SELECT ShowId,ShowName,Location,ShowDate,AvSeats,PriceTicket FROM ShowDetails";
		try {
			connect = util.getConnection();
			pst = connect.prepareStatement(query);
			ResultSet result = pst.executeQuery();
			while (result.next()) {
				Shows movie = new Shows();
				movie.setShowId(result.getString("ShowId"));
				movie.setShowName(result.getString("ShowName"));
				movie.setLocation(result.getString("Location"));
				movie.setShowDate(result.getDate("ShowDate"));
				movie.setAvSeats(result.getInt("AvSeats"));
				movie.setPriceTicket(result.getFloat("PriceTicket"));
				myShow.add(movie);
			}
		} catch (SQLException e) {
			throw new ShowException("Show All Method working failed", e);

		} finally {
			if (pst != null) {
				try {
					pst.close();
				} catch (SQLException e) {
					System.out.println("PrepareStatement closing failed");
				}
			}
			if (connect != null) {
				try {
					connect.close();
				} catch (SQLException e) {
					System.out.println("Connection closing failed");
				}
			}
		}
		return myShow;
	}

	@Override
	public Shows bookTicket(String name) throws ShowException {
		Connection connect = null;
		PreparedStatement pst = null;
		Shows set = null;
		String query = "SELECT ShowId,ShowName,PriceTicket,AvSeats FROM ShowDetails WHERE ShowId=?";
		try {
			connect = util.getConnection();
			pst = connect.prepareStatement(query);
			pst.setString(1, name);
			ResultSet result = pst.executeQuery();
			while (result.next()) {
				String showId = result.getString("ShowId");
				String sName = result.getString("ShowName");
				float price = result.getFloat("PriceTicket");
				int seats = result.getInt("AvSeats");
				set = new Shows();
				set.setShowId(showId);
				set.setShowName(sName);
				set.setPriceTicket(price);
				set.setAvSeats(seats);
			}
		} catch (SQLException e) {
			throw new ShowException("Book Ticket method Failed", e);

		} finally {
			if (pst != null) {
				try {
					pst.close();
				} catch (SQLException e) {
					System.out.println("PrepareStatement closing failed");
				}
			}
			if (connect != null) {
				try {
					connect.close();
				} catch (SQLException e) {
					System.out.println("Connection closing failed");
				}
			}
		}

		return set;
	}

	@Override
	public boolean updateSeats(int noOfSeats, String id) throws ShowException {
		Connection connect = null;
		PreparedStatement pst = null;

		String query = "UPDATE ShowDetails SET AvSeats=AvSeats-? WHERE ShowId=?";

		try {
			connect = util.getConnection();
			pst = connect.prepareStatement(query);
			pst.setInt(1, noOfSeats);
			pst.setString(2, id);
			int result = pst.executeUpdate();
			if (result > 0) {
				return true;
			}
			
		} catch (SQLException e) {
			throw new ShowException("Update query failed", e);
		} finally {
			if (pst != null) {
				try {
					pst.close();
				} catch (SQLException e) {
					System.out.println("PrepareStatement closing failed");
				}
			}
			if (connect != null) {
				try {
					connect.close();
				} catch (SQLException e) {
					System.out.println("Connection closing failed");
				}
			}
		}
		return false;

		
	}

}
