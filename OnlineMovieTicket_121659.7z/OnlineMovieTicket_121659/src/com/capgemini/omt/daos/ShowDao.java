package com.capgemini.omt.daos;

import java.util.List;

import com.capgemini.omt.dto.Shows;
import com.capgemini.omt.exceptions.ShowException;

public interface ShowDao {
	public List<Shows> showAll() throws ShowException;

	public Shows bookTicket(String name) throws ShowException;

	public boolean updateSeats(int noOfSeats, String id) throws ShowException;
}
