package com.capgemini.omt.dto;

import java.io.Serializable;
import java.sql.Date;

public class Shows implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String showId;
	private String showName;
	private String location;
	private Date showDate;
	private int avSeats;
	private float priceTicket;
	public Shows() {
		super();
	}
	public Shows(String showId, String showName, String location, Date showDate,
			int avSeats, float priceTicket) {
		super();
		this.showId = showId;
		this.showName = showName;
		this.location = location;
		this.showDate = showDate;
		this.avSeats = avSeats;
		this.priceTicket = priceTicket;
	}
	public String getShowId() {
		return showId;
	}
	public void setShowId(String showId) {
		this.showId = showId;
	}
	public String getShowName() {
		return showName;
	}
	public void setShowName(String showName) {
		this.showName = showName;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public Date getShowDate() {
		return showDate;
	}
	public void setShowDate(Date showDate) {
		this.showDate = showDate;
	}
	public int getAvSeats() {
		return avSeats;
	}
	public void setAvSeats(int avSeats) {
		this.avSeats = avSeats;
	}
	public float getPriceTicket() {
		return priceTicket;
	}
	public void setPriceTicket(float priceTicket) {
		this.priceTicket = priceTicket;
	}
	@Override
	public String toString() {
		return "Shows showId=" + showId + ", showName=" + showName
				+ ", location=" + location + ", showDate=" + showDate
				+ ", avSeats=" + avSeats + ", priceTicket=" + priceTicket;
	}
	
	
	
}
